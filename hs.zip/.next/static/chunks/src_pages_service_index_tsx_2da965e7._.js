(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__fe018c16._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
  "static/chunks/node_modules_next_dist_shared_lib_c53fc824._.js",
  "static/chunks/node_modules_next_dist_client_379e9c20._.js",
  "static/chunks/node_modules_next_dist_2ff056ee._.js",
  "static/chunks/node_modules_next_3d15e363._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_@headlessui_react_dist_c866b64e._.js",
  "static/chunks/node_modules_@floating-ui_react_dist_ca3caa08._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ab97e45._.js",
  "static/chunks/node_modules_042ecbb0._.js"
],
    source: "entry"
});
