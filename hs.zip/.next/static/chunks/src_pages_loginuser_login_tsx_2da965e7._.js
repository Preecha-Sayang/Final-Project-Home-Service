(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
  "static/chunks/node_modules_next_dist_shared_lib_6cf7e6c4._.js",
  "static/chunks/node_modules_next_dist_client_e4371d1d._.js",
  "static/chunks/node_modules_next_dist_2ff056ee._.js",
  "static/chunks/node_modules_next_f6e12e7e._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_be8bb86a._.js",
  "static/chunks/[root-of-the-server]__29048acf._.js"
],
    source: "entry"
});
