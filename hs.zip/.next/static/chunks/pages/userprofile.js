__turbopack_load_page_chunks__("/userprofile", [
  "static/chunks/[root-of-the-server]__ae2e6f14._.js",
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_98c9bed4._.js",
  "static/chunks/node_modules_next_dist_shared_lib_46a35751._.js",
  "static/chunks/node_modules_next_dist_client_379e9c20._.js",
  "static/chunks/node_modules_next_dist_2ff056ee._.js",
  "static/chunks/node_modules_next_f1d42476._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
  "static/chunks/node_modules_@headlessui_react_dist_c866b64e._.js",
  "static/chunks/node_modules_@floating-ui_react_dist_ca3caa08._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ab97e45._.js",
  "static/chunks/node_modules_a835eddb._.js",
  "static/chunks/src_pages_userprofile_2da965e7._.js",
  "static/chunks/turbopack-src_pages_userprofile_a8d07e44._.js"
])
