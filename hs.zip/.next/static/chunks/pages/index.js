__turbopack_load_page_chunks__("/", [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
  "static/chunks/node_modules_next_dist_shared_lib_46a35751._.js",
  "static/chunks/node_modules_next_dist_client_379e9c20._.js",
  "static/chunks/node_modules_next_dist_2ff056ee._.js",
  "static/chunks/node_modules_next_0a36fc09._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_64fd8a85._.js",
  "static/chunks/[root-of-the-server]__206ad862._.js",
  "static/chunks/src_pages_index_2da965e7._.js",
  "static/chunks/turbopack-src_pages_index_9d776a1c._.js"
])
