(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_e5a37f7a._.js",
  "static/chunks/node_modules_next_dist_shared_lib_854924ee._.js",
  "static/chunks/node_modules_next_dist_client_45e9549c._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_next_f1a19c82._.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
  "static/chunks/node_modules_ccf09c08._.js",
  "static/chunks/[root-of-the-server]__e1e2876f._.js",
  "static/chunks/[root-of-the-server]__ca428f58._.css"
],
    source: "entry"
});
