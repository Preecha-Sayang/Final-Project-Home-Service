(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
  "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
  "static/chunks/node_modules_next_dist_shared_lib_f041b118._.js",
  "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
  "static/chunks/node_modules_next_dist_2e2215b7._.js",
  "static/chunks/node_modules_next_link_207af988.js",
  "static/chunks/node_modules_react-dom_4411d9bd._.js",
  "static/chunks/node_modules_db346ff0._.js",
  "static/chunks/[root-of-the-server]__3bab634e._.js",
  "static/chunks/[next]_internal_font_google_prompt_6c2a56eb_module_97d8c2bb.css"
],
    source: "entry"
});
