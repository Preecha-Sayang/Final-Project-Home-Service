(globalThis.TURBOPACK || (globalThis.TURBOPACK = [])).push([typeof document === "object" ? document.currentScript : undefined,
"[turbopack]/browser/dev/hmr-client/hmr-client.ts [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

/// <reference path="../../../shared/runtime-types.d.ts" />
/// <reference path="../../runtime/base/dev-globals.d.ts" />
/// <reference path="../../runtime/base/dev-protocol.d.ts" />
/// <reference path="../../runtime/base/dev-extensions.ts" />
__turbopack_context__.s([
    "connect",
    ()=>connect,
    "setHooks",
    ()=>setHooks,
    "subscribeToUpdate",
    ()=>subscribeToUpdate
]);
function connect(param) {
    let { addMessageListener, sendMessage, onUpdateError = console.error } = param;
    addMessageListener((msg)=>{
        switch(msg.type){
            case 'turbopack-connected':
                handleSocketConnected(sendMessage);
                break;
            default:
                try {
                    if (Array.isArray(msg.data)) {
                        for(let i = 0; i < msg.data.length; i++){
                            handleSocketMessage(msg.data[i]);
                        }
                    } else {
                        handleSocketMessage(msg.data);
                    }
                    applyAggregatedUpdates();
                } catch (e) {
                    console.warn('[Fast Refresh] performing full reload\n\n' + "Fast Refresh will perform a full reload when you edit a file that's imported by modules outside of the React rendering tree.\n" + 'You might have a file which exports a React component but also exports a value that is imported by a non-React component file.\n' + 'Consider migrating the non-React component export to a separate file and importing it into both files.\n\n' + 'It is also possible the parent component of the component you edited is a class component, which disables Fast Refresh.\n' + 'Fast Refresh requires at least one parent function component in your React tree.');
                    onUpdateError(e);
                    location.reload();
                }
                break;
        }
    });
    const queued = globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS;
    if (queued != null && !Array.isArray(queued)) {
        throw new Error('A separate HMR handler was already registered');
    }
    globalThis.TURBOPACK_CHUNK_UPDATE_LISTENERS = {
        push: (param)=>{
            let [chunkPath, callback] = param;
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    };
    if (Array.isArray(queued)) {
        for (const [chunkPath, callback] of queued){
            subscribeToChunkUpdate(chunkPath, sendMessage, callback);
        }
    }
}
const updateCallbackSets = new Map();
function sendJSON(sendMessage, message) {
    sendMessage(JSON.stringify(message));
}
function resourceKey(resource) {
    return JSON.stringify({
        path: resource.path,
        headers: resource.headers || null
    });
}
function subscribeToUpdates(sendMessage, resource) {
    sendJSON(sendMessage, {
        type: 'turbopack-subscribe',
        ...resource
    });
    return ()=>{
        sendJSON(sendMessage, {
            type: 'turbopack-unsubscribe',
            ...resource
        });
    };
}
function handleSocketConnected(sendMessage) {
    for (const key of updateCallbackSets.keys()){
        subscribeToUpdates(sendMessage, JSON.parse(key));
    }
}
// we aggregate all pending updates until the issues are resolved
const chunkListsWithPendingUpdates = new Map();
function aggregateUpdates(msg) {
    const key = resourceKey(msg.resource);
    let aggregated = chunkListsWithPendingUpdates.get(key);
    if (aggregated) {
        aggregated.instruction = mergeChunkListUpdates(aggregated.instruction, msg.instruction);
    } else {
        chunkListsWithPendingUpdates.set(key, msg);
    }
}
function applyAggregatedUpdates() {
    if (chunkListsWithPendingUpdates.size === 0) return;
    hooks.beforeRefresh();
    for (const msg of chunkListsWithPendingUpdates.values()){
        triggerUpdate(msg);
    }
    chunkListsWithPendingUpdates.clear();
    finalizeUpdate();
}
function mergeChunkListUpdates(updateA, updateB) {
    let chunks;
    if (updateA.chunks != null) {
        if (updateB.chunks == null) {
            chunks = updateA.chunks;
        } else {
            chunks = mergeChunkListChunks(updateA.chunks, updateB.chunks);
        }
    } else if (updateB.chunks != null) {
        chunks = updateB.chunks;
    }
    let merged;
    if (updateA.merged != null) {
        if (updateB.merged == null) {
            merged = updateA.merged;
        } else {
            // Since `merged` is an array of updates, we need to merge them all into
            // one, consistent update.
            // Since there can only be `EcmascriptMergeUpdates` in the array, there is
            // no need to key on the `type` field.
            let update = updateA.merged[0];
            for(let i = 1; i < updateA.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateA.merged[i]);
            }
            for(let i = 0; i < updateB.merged.length; i++){
                update = mergeChunkListEcmascriptMergedUpdates(update, updateB.merged[i]);
            }
            merged = [
                update
            ];
        }
    } else if (updateB.merged != null) {
        merged = updateB.merged;
    }
    return {
        type: 'ChunkListUpdate',
        chunks,
        merged
    };
}
function mergeChunkListChunks(chunksA, chunksB) {
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    return chunks;
}
function mergeChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted' || updateA.type === 'deleted' && updateB.type === 'added') {
        return undefined;
    }
    if (updateA.type === 'partial') {
        invariant(updateA.instruction, 'Partial updates are unsupported');
    }
    if (updateB.type === 'partial') {
        invariant(updateB.instruction, 'Partial updates are unsupported');
    }
    return undefined;
}
function mergeChunkListEcmascriptMergedUpdates(mergedA, mergedB) {
    const entries = mergeEcmascriptChunkEntries(mergedA.entries, mergedB.entries);
    const chunks = mergeEcmascriptChunksUpdates(mergedA.chunks, mergedB.chunks);
    return {
        type: 'EcmascriptMergedUpdate',
        entries,
        chunks
    };
}
function mergeEcmascriptChunkEntries(entriesA, entriesB) {
    return {
        ...entriesA,
        ...entriesB
    };
}
function mergeEcmascriptChunksUpdates(chunksA, chunksB) {
    if (chunksA == null) {
        return chunksB;
    }
    if (chunksB == null) {
        return chunksA;
    }
    const chunks = {};
    for (const [chunkPath, chunkUpdateA] of Object.entries(chunksA)){
        const chunkUpdateB = chunksB[chunkPath];
        if (chunkUpdateB != null) {
            const mergedUpdate = mergeEcmascriptChunkUpdates(chunkUpdateA, chunkUpdateB);
            if (mergedUpdate != null) {
                chunks[chunkPath] = mergedUpdate;
            }
        } else {
            chunks[chunkPath] = chunkUpdateA;
        }
    }
    for (const [chunkPath, chunkUpdateB] of Object.entries(chunksB)){
        if (chunks[chunkPath] == null) {
            chunks[chunkPath] = chunkUpdateB;
        }
    }
    if (Object.keys(chunks).length === 0) {
        return undefined;
    }
    return chunks;
}
function mergeEcmascriptChunkUpdates(updateA, updateB) {
    if (updateA.type === 'added' && updateB.type === 'deleted') {
        // These two completely cancel each other out.
        return undefined;
    }
    if (updateA.type === 'deleted' && updateB.type === 'added') {
        const added = [];
        const deleted = [];
        var _updateA_modules;
        const deletedModules = new Set((_updateA_modules = updateA.modules) !== null && _updateA_modules !== void 0 ? _updateA_modules : []);
        var _updateB_modules;
        const addedModules = new Set((_updateB_modules = updateB.modules) !== null && _updateB_modules !== void 0 ? _updateB_modules : []);
        for (const moduleId of addedModules){
            if (!deletedModules.has(moduleId)) {
                added.push(moduleId);
            }
        }
        for (const moduleId of deletedModules){
            if (!addedModules.has(moduleId)) {
                deleted.push(moduleId);
            }
        }
        if (added.length === 0 && deleted.length === 0) {
            return undefined;
        }
        return {
            type: 'partial',
            added,
            deleted
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'partial') {
        var _updateA_added, _updateB_added;
        const added = new Set([
            ...(_updateA_added = updateA.added) !== null && _updateA_added !== void 0 ? _updateA_added : [],
            ...(_updateB_added = updateB.added) !== null && _updateB_added !== void 0 ? _updateB_added : []
        ]);
        var _updateA_deleted, _updateB_deleted;
        const deleted = new Set([
            ...(_updateA_deleted = updateA.deleted) !== null && _updateA_deleted !== void 0 ? _updateA_deleted : [],
            ...(_updateB_deleted = updateB.deleted) !== null && _updateB_deleted !== void 0 ? _updateB_deleted : []
        ]);
        if (updateB.added != null) {
            for (const moduleId of updateB.added){
                deleted.delete(moduleId);
            }
        }
        if (updateB.deleted != null) {
            for (const moduleId of updateB.deleted){
                added.delete(moduleId);
            }
        }
        return {
            type: 'partial',
            added: [
                ...added
            ],
            deleted: [
                ...deleted
            ]
        };
    }
    if (updateA.type === 'added' && updateB.type === 'partial') {
        var _updateA_modules1, _updateB_added1;
        const modules = new Set([
            ...(_updateA_modules1 = updateA.modules) !== null && _updateA_modules1 !== void 0 ? _updateA_modules1 : [],
            ...(_updateB_added1 = updateB.added) !== null && _updateB_added1 !== void 0 ? _updateB_added1 : []
        ]);
        var _updateB_deleted1;
        for (const moduleId of (_updateB_deleted1 = updateB.deleted) !== null && _updateB_deleted1 !== void 0 ? _updateB_deleted1 : []){
            modules.delete(moduleId);
        }
        return {
            type: 'added',
            modules: [
                ...modules
            ]
        };
    }
    if (updateA.type === 'partial' && updateB.type === 'deleted') {
        var _updateB_modules1;
        // We could eagerly return `updateB` here, but this would potentially be
        // incorrect if `updateA` has added modules.
        const modules = new Set((_updateB_modules1 = updateB.modules) !== null && _updateB_modules1 !== void 0 ? _updateB_modules1 : []);
        if (updateA.added != null) {
            for (const moduleId of updateA.added){
                modules.delete(moduleId);
            }
        }
        return {
            type: 'deleted',
            modules: [
                ...modules
            ]
        };
    }
    // Any other update combination is invalid.
    return undefined;
}
function invariant(_, message) {
    throw new Error("Invariant: ".concat(message));
}
const CRITICAL = [
    'bug',
    'error',
    'fatal'
];
function compareByList(list, a, b) {
    const aI = list.indexOf(a) + 1 || list.length;
    const bI = list.indexOf(b) + 1 || list.length;
    return aI - bI;
}
const chunksWithIssues = new Map();
function emitIssues() {
    const issues = [];
    const deduplicationSet = new Set();
    for (const [_, chunkIssues] of chunksWithIssues){
        for (const chunkIssue of chunkIssues){
            if (deduplicationSet.has(chunkIssue.formatted)) continue;
            issues.push(chunkIssue);
            deduplicationSet.add(chunkIssue.formatted);
        }
    }
    sortIssues(issues);
    hooks.issues(issues);
}
function handleIssues(msg) {
    const key = resourceKey(msg.resource);
    let hasCriticalIssues = false;
    for (const issue of msg.issues){
        if (CRITICAL.includes(issue.severity)) {
            hasCriticalIssues = true;
        }
    }
    if (msg.issues.length > 0) {
        chunksWithIssues.set(key, msg.issues);
    } else if (chunksWithIssues.has(key)) {
        chunksWithIssues.delete(key);
    }
    emitIssues();
    return hasCriticalIssues;
}
const SEVERITY_ORDER = [
    'bug',
    'fatal',
    'error',
    'warning',
    'info',
    'log'
];
const CATEGORY_ORDER = [
    'parse',
    'resolve',
    'code generation',
    'rendering',
    'typescript',
    'other'
];
function sortIssues(issues) {
    issues.sort((a, b)=>{
        const first = compareByList(SEVERITY_ORDER, a.severity, b.severity);
        if (first !== 0) return first;
        return compareByList(CATEGORY_ORDER, a.category, b.category);
    });
}
const hooks = {
    beforeRefresh: ()=>{},
    refresh: ()=>{},
    buildOk: ()=>{},
    issues: (_issues)=>{}
};
function setHooks(newHooks) {
    Object.assign(hooks, newHooks);
}
function handleSocketMessage(msg) {
    sortIssues(msg.issues);
    handleIssues(msg);
    switch(msg.type){
        case 'issues':
            break;
        case 'partial':
            // aggregate updates
            aggregateUpdates(msg);
            break;
        default:
            // run single update
            const runHooks = chunkListsWithPendingUpdates.size === 0;
            if (runHooks) hooks.beforeRefresh();
            triggerUpdate(msg);
            if (runHooks) finalizeUpdate();
            break;
    }
}
function finalizeUpdate() {
    hooks.refresh();
    hooks.buildOk();
    // This is used by the Next.js integration test suite to notify it when HMR
    // updates have been completed.
    // TODO: Only run this in test environments (gate by `process.env.__NEXT_TEST_MODE`)
    if (globalThis.__NEXT_HMR_CB) {
        globalThis.__NEXT_HMR_CB();
        globalThis.__NEXT_HMR_CB = null;
    }
}
function subscribeToChunkUpdate(chunkListPath, sendMessage, callback) {
    return subscribeToUpdate({
        path: chunkListPath
    }, sendMessage, callback);
}
function subscribeToUpdate(resource, sendMessage, callback) {
    const key = resourceKey(resource);
    let callbackSet;
    const existingCallbackSet = updateCallbackSets.get(key);
    if (!existingCallbackSet) {
        callbackSet = {
            callbacks: new Set([
                callback
            ]),
            unsubscribe: subscribeToUpdates(sendMessage, resource)
        };
        updateCallbackSets.set(key, callbackSet);
    } else {
        existingCallbackSet.callbacks.add(callback);
        callbackSet = existingCallbackSet;
    }
    return ()=>{
        callbackSet.callbacks.delete(callback);
        if (callbackSet.callbacks.size === 0) {
            callbackSet.unsubscribe();
            updateCallbackSets.delete(key);
        }
    };
}
function triggerUpdate(msg) {
    const key = resourceKey(msg.resource);
    const callbackSet = updateCallbackSets.get(key);
    if (!callbackSet) {
        return;
    }
    for (const callback of callbackSet.callbacks){
        callback(msg);
    }
    if (msg.type === 'notFound') {
        // This indicates that the resource which we subscribed to either does not exist or
        // has been deleted. In either case, we should clear all update callbacks, so if a
        // new subscription is created for the same resource, it will send a new "subscribe"
        // message to the server.
        // No need to send an "unsubscribe" message to the server, it will have already
        // dropped the update stream before sending the "notFound" message.
        updateCallbackSets.delete(key);
    }
}
}),
"[project]/src/components/radio/radio_botton.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
;
function RadioButton(param) {
    let { id, name, value, checked = false, disabled = false, onChange, label } = param;
    /**
   * ฟังก์ชันจัดการเมื่อมีการเปลี่ยนแปลงค่า
   * จะทำงานเฉพาะเมื่อปุ่มไม่ถูกปิดใช้งาน
   */ const handleChange = (e)=>{
        if (!disabled && onChange) {
            onChange(value);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "inline-block my-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                type: "radio",
                id: id,
                name: name,
                value: value,
                checked: checked,
                disabled: disabled,
                onChange: handleChange,
                className: "sr-only"
            }, void 0, false, {
                fileName: "[project]/src/components/radio/radio_botton.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("label", {
                htmlFor: id,
                className: "\n          flex items-center text-sm font-normal select-none transition-all duration-200\n          ".concat(disabled ? 'cursor-not-allowed text-gray-400' : 'cursor-pointer text-gray-700 hover:text-blue-500', "\n        "),
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                        className: "\n            relative w-[20px] h-[20px] mr-2 rounded-full border-2 bg-white transition-all duration-200\n            ".concat(disabled ? checked ? 'border-gray-300 bg-gray-50' : 'border-gray-300 bg-gray-50' : checked ? 'border-blue-500 bg-white' : 'border-gray-300 hover:border-blue-500', "\n          "),
                        children: checked && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                            className: "\n                absolute top-1/2 left-1/2 w-2 h-2 rounded-full transform -translate-x-1/2 -translate-y-1/2\n                ".concat(disabled ? 'bg-gray-400' : 'bg-blue-500', "\n              ")
                        }, void 0, false, {
                            fileName: "[project]/src/components/radio/radio_botton.tsx",
                            lineNumber: 73,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/radio/radio_botton.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    label
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/radio/radio_botton.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/radio/radio_botton.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
_c = RadioButton;
const __TURBOPACK__default__export__ = RadioButton;
var _c;
__turbopack_context__.k.register(_c, "RadioButton");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
 /* ----------------------------------------------------
  วิธีใช้งาน RadioButton Component

  RadioButton Component เป็น custom radio button ที่มีสไตล์
  รองรับการใช้งานแบบ controlled และ uncontrolled
  มีการแสดงผลที่สอดคล้องกับ design system ของแอปพลิเคชัน
  ใช้สำหรับการเลือกตัวเลือกเดียวจากหลายตัวเลือก

  Props:
  - id: string (required) - ID ของ radio button (ต้องไม่ซ้ำกัน)
  - name: string (required) - ชื่อกลุ่มของ radio buttons (ต้องเหมือนกันในกลุ่ม)
  - value: string (required) - ค่าของ radio button
  - checked: boolean (optional) - สถานะการเลือก (default: false)
  - disabled: boolean (optional) - ปิดใช้งาน radio button (default: false)
  - onChange: function (optional) - ฟังก์ชันที่เรียกเมื่อมีการเปลี่ยนแปลงค่า
  - label: string (required) - ข้อความที่แสดงข้าง radio button

  ตัวอย่างการใช้งาน:

  1) การใช้งานพื้นฐาน:
     import RadioButton from "@/components/radio/radio_botton";
     
     const [selectedOption, setSelectedOption] = useState("");
     
     <div className="space-y-3">
       <RadioButton 
         id="option1"
         name="basic-options"
         value="option1"
         label="ตัวเลือกที่ 1"
         checked={selectedOption === "option1"}
         onChange={setSelectedOption}
       />
     </div>

  2) การใช้งานแบบ Disabled:
     <div className="space-y-2">
       <RadioButton 
         id="enabled-option"
         name="disabled-demo"
         value="enabled"
         label="ตัวเลือกที่ใช้งานได้"
         checked={true}
         onChange={(value) => console.log(value)}
       />
       <RadioButton 
         id="disabled-option"
         name="disabled-demo"
         value="disabled"
         label="ตัวเลือกที่ปิดใช้งาน"
         checked={false}
         disabled={true}
       />
     </div>


  การแสดงผล:
  - Radio button มีขนาด 20x20 pixels
  - สีน้ำเงินเมื่อถูกเลือก
  - สีเทาเมื่อปิดใช้งาน
  - มี hover effect เมื่อ hover
  - มี transition animation ที่นุ่มนวล
  - รองรับการแสดงผลแบบ responsive

  หมายเหตุ:
  - id ต้องไม่ซ้ำกันในหน้าเดียวกัน
  - name ต้องเหมือนกันในกลุ่ม radio buttons เดียวกัน
  - value ควรเป็นค่าที่ไม่ซ้ำกันในกลุ่ม
  - onChange จะไม่ทำงานเมื่อ disabled
  - รองรับการใช้งานแบบ controlled และ uncontrolled
  - ใช้กับ form libraries เช่น react-hook-form ได้

  การใช้งานกับ Form Libraries:
  
  React Hook Form:
     const { register, watch, setValue } = useForm();
     
     <RadioButton 
       id="form-radio"
       name="form-option"
       value="option1"
       label="ตัวเลือก 1"
       checked={watch('option') === 'option1'}
       onChange={(value) => setValue('option', value)}
     />

  Formik:
     <RadioButton 
       id="formik-radio"
       name="formik-option"
       value="option1"
       label="ตัวเลือก 1"
       checked={formik.values.option === 'option1'}
       onChange={(value) => formik.setFieldValue('option', value)}
     />

  การใช้งานแบบ Group Management:
     const [radioGroups, setRadioGroups] = useState({
       group1: "",
       group2: "",
       group3: ""
     });
     
     const handleGroupChange = (groupName: string, value: string) => {
       setRadioGroups(prev => ({
         ...prev,
         [groupName]: value
       }));
     };
     
     <div className="space-y-6">
       <div>
         <h3>กลุ่มที่ 1:</h3>
         <RadioButton 
           id="g1-option1"
           name="group1"
           value="option1"
           label="ตัวเลือก 1"
           checked={radioGroups.group1 === "option1"}
           onChange={(value) => handleGroupChange('group1', value)}
         />
       </div>
     </div>

---------------------------------------------------- */ }),
"[project]/src/components/radio/radio_input.tsx [client] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RadioButtonWithInput",
    ()=>RadioButtonWithInput
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react/jsx-dev-runtime.js [client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$radio$2f$radio_botton$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/radio/radio_botton.tsx [client] (ecmascript)");
;
;
function RadioButtonWithInput(param) {
    let { id, name, value, checked, disabled, onChange, onInputChange, className, placeholder, inputValue, label, postfix = '฿' } = param;
    /**
     * ฟังก์ชันจัดการเมื่อมีการเปลี่ยนแปลงค่าใน input field
     * จะทำงานเฉพาะเมื่อ input ไม่ถูกปิดใช้งาน
     */ const handleInputChange = (e)=>{
        if (!disabled && onInputChange) {
            onInputChange(e.target.value);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: "flex items-center space-x-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$radio$2f$radio_botton$2e$tsx__$5b$client$5d$__$28$ecmascript$29$__["default"], {
                    id: id,
                    name: name,
                    value: value,
                    label: label,
                    checked: checked,
                    disabled: disabled,
                    onChange: onChange
                }, void 0, false, {
                    fileName: "[project]/src/components/radio/radio_input.tsx",
                    lineNumber: 105,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: "flex-1 max-w-xs",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                        className: "relative ".concat(className),
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                                type: "text",
                                value: inputValue || "",
                                onChange: handleInputChange,
                                placeholder: placeholder,
                                disabled: disabled,
                                className: "\n                                w-full h-[42px] pt-[9px] pr-[13px] pb-[9px] pl-[13px]\n                                bg-gray-100 \n                                border border-gray-300 \n                                rounded-[6px] \n                                text-sm \n                                text-gray-700\n                                placeholder-gray-400\n                                focus:outline-none \n                                focus:ring-2 \n                                focus:ring-blue-500 \n                                focus:border-transparent\n                                transition-all duration-200\n                                shadow-sm\n                                ".concat(disabled ? 'cursor-not-allowed bg-gray-50 text-gray-400' : 'hover:bg-gray-50', "\n                            ")
                            }, void 0, false, {
                                fileName: "[project]/src/components/radio/radio_input.tsx",
                                lineNumber: 118,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                className: "absolute right-[13px] top-1/2 transform -translate-y-1/2 pointer-events-none",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                    className: "text-gray-500 text-sm font-medium",
                                    children: postfix
                                }, void 0, false, {
                                    fileName: "[project]/src/components/radio/radio_input.tsx",
                                    lineNumber: 147,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/radio/radio_input.tsx",
                                lineNumber: 146,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/radio/radio_input.tsx",
                        lineNumber: 117,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/radio/radio_input.tsx",
                    lineNumber: 116,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/radio/radio_input.tsx",
            lineNumber: 104,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/radio/radio_input.tsx",
        lineNumber: 102,
        columnNumber: 9
    }, this);
} /**
 * วิธีใช้งาน RadioButtonWithInput Component
 * 
 * RadioButtonWithInput Component เป็นคอมโพเนนต์ที่รวม radio button กับ input field
 * เหมาะสำหรับการเลือกตัวเลือกพร้อมกับการป้อนข้อมูลเพิ่มเติม
 * 
 * คุณสมบัติหลัก:
 * - Radio button สำหรับเลือกตัวเลือก
 * - Input field สำหรับป้อนข้อมูลเพิ่มเติม
 * - รองรับการปิดใช้งาน (disabled state)
 * - มี postfix แสดงด้านขวาของ input (เช่น สัญลักษณ์สกุลเงิน)
 * - สไตล์ที่สอดคล้องกับ design system
 * 
 * ตัวอย่างการใช้งาน:
 * 
 * 1) การใช้งานพื้นฐาน - การเลือกวิธีการชำระเงิน:
 *    const [selectedPayment, setSelectedPayment] = useState("");
 *    const [amount, setAmount] = useState("");
 *    
 *    <div className="space-y-4">
 *      <RadioButtonWithInput
 *        id="cash-payment"
 *        name="payment-method"
 *        value="cash"
 *        label="เงินสด"
 *        checked={selectedPayment === "cash"}
 *        onChange={setSelectedPayment}
 *        inputValue={amount}
 *        onInputChange={setAmount}
 *        placeholder="ระบุจำนวนเงิน"
 *        postfix="฿"
 *      />
 *    </div>
 * 
 * 3) การใช้งานแบบ Disabled:
 *    <div className="space-y-3">
 *      <RadioButtonWithInput
 *        id="enabled-option"
 *        name="demo"
 *        value="enabled"
 *        label="ตัวเลือกที่ใช้งานได้"
 *        checked={true}
 *        onChange={(value) => console.log(value)}
 *        inputValue="1000"
 *        onInputChange={(value) => console.log(value)}
 *        placeholder="ระบุจำนวน"
 *        postfix="฿"
 *      />
 *      <RadioButtonWithInput
 *        id="disabled-option"
 *        name="demo"
 *        value="disabled"
 *        label="ตัวเลือกที่ปิดใช้งาน"
 *        checked={false}
 *        disabled={true}
 *        inputValue=""
 *        placeholder="ไม่สามารถป้อนข้อมูลได้"
 *        postfix="฿"
 *      />
 *    </div>
 * 
 * การแสดงผล:
 * - Radio button แสดงด้านซ้าย
 * - Input field แสดงด้านขวาของ radio button
 * - Postfix แสดงด้านขวาของ input field
 * - รองรับ responsive design
 * - มี hover และ focus states
 * - รองรับ disabled state
 * 
 * Best Practices:
 * 1. ใช้ name เดียวกันสำหรับ radio button ที่อยู่ในกลุ่มเดียวกัน
 * 2. ใช้ id ที่ไม่ซ้ำกันสำหรับแต่ละ radio button
 * 3. จัดการ state ให้เหมาะสมกับ use case
 * 4. ใช้ placeholder ที่ชัดเจนและเข้าใจง่าย
 * 5. เลือก postfix ที่เหมาะสมกับข้อมูลที่ป้อน
 * 6. ตรวจสอบ validation ของข้อมูลที่ป้อนใน input field
 * 
 * การใช้งานกับ Form Libraries:
 * 
 * React Hook Form:
 * ```tsx
 * const { register, watch, setValue } = useForm();
 * const selectedValue = watch("paymentMethod");
 * const inputValue = watch("amount");
 * 
 * <RadioButtonWithInput
 *   id="cash"
 *   name="paymentMethod"
 *   value="cash"
 *   label="เงินสด"
 *   checked={selectedValue === "cash"}
 *   onChange={(value) => setValue("paymentMethod", value)}
 *   inputValue={inputValue}
 *   onInputChange={(value) => setValue("amount", value)}
 *   placeholder="ระบุจำนวนเงิน"
 *   postfix="฿"
 * />
 */ 
_c = RadioButtonWithInput;
var _c;
__turbopack_context__.k.register(_c, "RadioButtonWithInput");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_context__.k.registerExports(__turbopack_context__.m, globalThis.$RefreshHelpers$);
}
}),
"[project]/src/pages/index.tsx [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/src/pages/index.tsx'\n\nExpected ',', got '='");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/index.tsx [client] (ecmascript)\" } [client] (ecmascript)", ((__turbopack_context__, module, exports) => {

const PAGE_PATH = "/";
(window.__NEXT_P = window.__NEXT_P || []).push([
    PAGE_PATH,
    ()=>{
        return __turbopack_context__.r("[project]/src/pages/index.tsx [client] (ecmascript)");
    }
]);
// @ts-expect-error module.hot exists
if (module.hot) {
    // @ts-expect-error module.hot exists
    module.hot.dispose(function() {
        window.__NEXT_P.push([
            PAGE_PATH
        ]);
    });
}
}),
"[hmr-entry]/hmr-entry.js { ENTRY => \"[project]/src/pages/index\" }", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.r("[next]/entry/page-loader.ts { PAGE => \"[project]/src/pages/index.tsx [client] (ecmascript)\" } [client] (ecmascript)");
}),
]);

//# sourceMappingURL=%5Broot-of-the-server%5D__8d9381f0._.js.map