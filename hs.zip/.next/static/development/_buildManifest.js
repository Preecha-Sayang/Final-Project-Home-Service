self.__BUILD_MANIFEST = {
  "/": [
    "./static/chunks/pages/index.js"
  ],
  "/404": [
    "./static/chunks/pages/404.js"
  ],
  "/_error": [
    "./static/chunks/pages/_error.js"
  ],
  "/login": [
    "./static/chunks/pages/login.js"
  ],
  "/register": [
    "./static/chunks/pages/register.js"
  ],
  "/userprofile": [
    "./static/chunks/pages/userprofile.js"
  ],
  "__rewrites": {
    "afterFiles": [],
    "beforeFiles": [],
    "fallback": []
  },
  "sortedPages": [
    "/",
    "/404",
    "/_app",
    "/_error",
    "/admin",
    "/admin/categories",
    "/admin/login",
    "/admin/promotion",
    "/admin/services",
    "/admin/services/new",
    "/admin/services/[id]",
    "/admin/services/[id]/edit",
    "/afterservice",
    "/afterservice/servicelist-process",
    "/afterservice/servicelist-success",
    "/api/admin",
    "/api/admin/create",
    "/api/admin/login",
    "/api/afterservice/order",
    "/api/auth/login",
    "/api/auth/refresh",
    "/api/auth/signup",
    "/api/categories",
    "/api/categories/units",
    "/api/categories/[id]",
    "/api/hello",
    "/api/location/districts",
    "/api/location/provinces",
    "/api/protected/protectapi",
    "/api/service-options/units",
    "/api/service-options/[id]",
    "/api/services",
    "/api/services/reorder",
    "/api/services/[id]",
    "/api/services/[id]/options",
    "/api/services-cards",
    "/api/test",
    "/api/upload",
    "/api/upload/upload-url",
    "/login",
    "/register",
    "/services",
    "/userprofile"
  ]
};self.__BUILD_MANIFEST_CB && self.__BUILD_MANIFEST_CB()