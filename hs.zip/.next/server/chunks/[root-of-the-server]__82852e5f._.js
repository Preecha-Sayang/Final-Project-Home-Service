module.exports = [
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/pg [external] (pg, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("pg");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/src/pages/api/services-cards.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>handler
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/pg [external] (pg, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
// สร้างการเชื่อมต่อฐานข้อมูล
const databasePool = new __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__["Pool"]({
    connectionString: process.env.DATABASE_URL
});
async function handler(request, response) {
    if (request.method !== "GET") {
        response.setHeader("Allow", [
            "GET"
        ]);
        return response.status(405).json({
            message: `Method ${request.method} Not Allowed`
        });
    }
    const { topOnly } = request.query;
    try {
        const client = await databasePool.connect();
        let query = `
      SELECT 
        s.service_id,
        s.servicename,
        s.image_url,
        s.description,
        c.name AS category,
        MIN(o.unit_price) AS min_price,
        MAX(o.unit_price) AS max_price
      FROM services s
      JOIN service_categories c ON s.category_id = c.category_id
      LEFT JOIN service_option o ON s.service_id = o.service_id
      GROUP BY s.service_id, s.servicename, s.image_url, s.description, c.name
    `;
        if (topOnly === "true") {
            query += ` ORDER BY RANDOM() LIMIT 3;`; // ดึงแรนด้อม 3 อัน
        } else {
            query += ` ORDER BY s.service_id ASC;`; // ดึงทุก service
        }
        const { rows } = await client.query(query);
        client.release();
        const services = rows.map((row)=>{
            const minPrice = Number(row.min_price);
            const maxPrice = Number(row.max_price);
            let priceText;
            if (minPrice === maxPrice) {
                priceText = `ค่าบริการประมาณ ${minPrice.toLocaleString()} ฿`;
            } else {
                priceText = `ค่าบริการประมาณ ${minPrice.toLocaleString()} - ${maxPrice.toLocaleString()} ฿`;
            }
            return {
                service_id: row.service_id,
                servicename: row.servicename,
                category: row.category,
                image_url: row.image_url,
                price: priceText,
                description: row.description,
                min_price: minPrice,
                max_price: maxPrice
            };
        });
        return response.status(200).json(services);
    } catch (error) {
        console.error("Error fetching services:", error);
        return response.status(500).json({
            message: "Internal server error"
        });
    }
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__82852e5f._.js.map