module.exports = [
"[externals]/next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/pages-api-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/pg [external] (pg, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("pg");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[externals]/@neondatabase/serverless [external] (@neondatabase/serverless, esm_import)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

const mod = await __turbopack_context__.y("@neondatabase/serverless");

__turbopack_context__.n(mod);
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, true);}),
"[project]/lib/db.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__,
    "query",
    ()=>query,
    "sql",
    ()=>sql
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/pg [external] (pg, esm_import)");
var __TURBOPACK__imported__module__$5b$externals$5d2f40$neondatabase$2f$serverless__$5b$external$5d$__$2840$neondatabase$2f$serverless$2c$__esm_import$29$__ = __turbopack_context__.i("[externals]/@neondatabase/serverless [external] (@neondatabase/serverless, esm_import)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__,
    __TURBOPACK__imported__module__$5b$externals$5d2f40$neondatabase$2f$serverless__$5b$external$5d$__$2840$neondatabase$2f$serverless$2c$__esm_import$29$__
]);
[__TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__, __TURBOPACK__imported__module__$5b$externals$5d2f40$neondatabase$2f$serverless__$5b$external$5d$__$2840$neondatabase$2f$serverless$2c$__esm_import$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
;
// ถ้ามี pool อยู่แล้ว ใช้ตัวเดิม, ถ้าไม่สร้างใหม่
const pool = global.pgPool || new __TURBOPACK__imported__module__$5b$externals$5d2f$pg__$5b$external$5d$__$28$pg$2c$__esm_import$29$__["Pool"]({
    connectionString: process.env.DATABASE_URL,
    ssl: {
        rejectUnauthorized: false
    }
});
if ("TURBOPACK compile-time truthy", 1) global.pgPool = pool;
const query = (text, params)=>pool.query(text, params);
const __TURBOPACK__default__export__ = pool;
const sql = (0, __TURBOPACK__imported__module__$5b$externals$5d2f40$neondatabase$2f$serverless__$5b$external$5d$__$2840$neondatabase$2f$serverless$2c$__esm_import$29$__["neon"])(process.env.DATABASE_URL); //สร้างใหม่ สำหรับอัปโหลดรูป
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
"[project]/src/pages/api/categories/index.ts [api] (ecmascript)", ((__turbopack_context__) => {
"use strict";

return __turbopack_context__.a(async (__turbopack_handle_async_dependencies__, __turbopack_async_result__) => { try {

__turbopack_context__.s([
    "default",
    ()=>handler
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/lib/db.ts [api] (ecmascript)");
var __turbopack_async_dependencies__ = __turbopack_handle_async_dependencies__([
    __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__
]);
[__TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__] = __turbopack_async_dependencies__.then ? (await __turbopack_async_dependencies__)() : __turbopack_async_dependencies__;
;
async function handler(req, res) {
    if (req.method === "GET") {
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["sql"] /*sql*/ `
            SELECT category_id, name, description, bg_color_hex, text_color_hex, ring_color_hex,
                    created_at, updated_at
            FROM service_categories
            ORDER BY category_id ASC
        `;
        return res.status(200).json({
            ok: true,
            categories: rows
        });
    }
    if (req.method === "POST") {
        const { name, description, bg_color_hex, text_color_hex, ring_color_hex } = req.body;
        if (!name?.trim()) return res.status(400).json({
            ok: false,
            message: "name required"
        });
        const rows = await __TURBOPACK__imported__module__$5b$project$5d2f$lib$2f$db$2e$ts__$5b$api$5d$__$28$ecmascript$29$__["sql"] /*sql*/ `
            INSERT INTO service_categories (name, description, bg_color_hex, text_color_hex, ring_color_hex, updated_at)
            VALUES (${name.trim()}, ${description ?? null}, ${bg_color_hex ?? null}, ${text_color_hex ?? null}, ${ring_color_hex ?? null}, now())
            RETURNING *
        `;
        return res.status(200).json({
            ok: true,
            category: rows[0]
        });
    }
    return res.status(405).end();
}
__turbopack_async_result__();
} catch(e) { __turbopack_async_result__(e); } }, false);}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__27166372._.js.map