module.exports = [
"[project]/src/components/radio/select_box.tsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>SelectBox
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react [external] (react, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/image.js [ssr] (ecmascript)");
;
;
;
function SelectBox({ id, label, icon = "/images/icon_qr.svg", iconHover = "/images/qr_code_2_blue_24dp 1 (2).svg", selected: controlledSelected, disabled = false, width = "w-[227px]", height = "h-[86px]", onClick, className = "", defaultText = "Default", selectedText = "Selected", hoverText = "Hover" }) {
    const [internalSelected, setInternalSelected] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    const [hovered, setHovered] = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react__$5b$external$5d$__$28$react$2c$__cjs$29$__["useState"])(false);
    // Use controlled or uncontrolled state
    const isSelected = controlledSelected !== undefined ? controlledSelected : internalSelected;
    const handleClick = ()=>{
        if (disabled) return;
        const newSelected = !isSelected;
        if (controlledSelected === undefined) {
            setInternalSelected(newSelected);
        }
        if (onClick) {
            onClick(newSelected);
        }
    };
    const handleMouseEnter = ()=>{
        if (!disabled) {
            setHovered(true);
        }
    };
    const handleMouseLeave = ()=>{
        setHovered(false);
    };
    const getDisplayText = ()=>{
        if (label) return label;
        if (isSelected) return selectedText;
        if (hovered && !disabled) return hoverText;
        return defaultText;
    };
    const getIconSrc = ()=>{
        if (isSelected || hovered && !disabled) {
            return iconHover;
        }
        return icon;
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("button", {
        id: id,
        onClick: handleClick,
        onMouseEnter: handleMouseEnter,
        onMouseLeave: handleMouseLeave,
        disabled: disabled,
        className: `
        group 
        ${width} ${height}
        flex flex-col items-center justify-center 
        rounded-[5px] border transition-all
        ${disabled ? "bg-gray-100 border-gray-200 cursor-not-allowed opacity-60" : isSelected ? "bg-blue-50 border-blue-500" : "bg-white border-gray-300 hover:border-blue-500"}
        ${className}
      `,
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$image$2e$js__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                src: getIconSrc(),
                alt: label || "Icon",
                width: 32,
                height: 32,
                className: `transition-all ${disabled ? "opacity-50" : ""}`
            }, void 0, false, {
                fileName: "[project]/src/components/radio/select_box.tsx",
                lineNumber: 101,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                className: `mt-2 font-medium transition-all ${disabled ? "text-gray-400" : isSelected ? "text-blue-600" : hovered ? "text-blue-600" : "text-gray-500"}`,
                children: getDisplayText()
            }, void 0, false, {
                fileName: "[project]/src/components/radio/select_box.tsx",
                lineNumber: 110,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/radio/select_box.tsx",
        lineNumber: 80,
        columnNumber: 5
    }, this);
} /**
 * วิธีใช้งาน SelectBox Component
 * 
 * SelectBox Component เป็นคอมโพเนนต์ที่ใช้สำหรับการเลือกตัวเลือกต่างๆ
 * มีไอคอนและข้อความที่เปลี่ยนแปลงตามสถานะ (ปกติ, hover, selected)
 * 
 * คุณสมบัติหลัก:
 * - ไอคอนที่เปลี่ยนแปลงตามสถานะ
 * - ข้อความที่เปลี่ยนแปลงตามสถานะ
 * - รองรับการปิดใช้งาน (disabled state)
 * - รองรับ controlled และ uncontrolled mode
 * - Hover effects และ transitions
 * - Customizable size และ styling
 * 
 * ตัวอย่างการใช้งาน:
 * 
 * 1) การใช้งานพื้นฐาน - การเลือกวิธีการชำระเงิน:
 *    const [selectedPayment, setSelectedPayment] = useState("");
 *    
 *    <div className="flex gap-4">
 *      <SelectBox
 *        id="qr-payment"
 *        label="QR Code"
 *        icon="/images/icon_qr.svg"
 *        iconHover="/images/qr_code_2_blue_24dp 1 (2).svg"
 *        selected={selectedPayment === "qr"}
 *        onClick={(selected) => setSelectedPayment(selected ? "qr" : "")}
 *      />
 *    </div>
 
 * 
 * 2) การใช้งานแบบ Disabled:
 *    <div className="flex gap-4">
 *      <SelectBox
 *        id="enabled-option"
 *        label="ใช้งานได้"
 *        icon="/images/icon_qr.svg"
 *        iconHover="/images/qr_code_2_blue_24dp 1 (2).svg"
 *        selected={true}
 *        onClick={(selected) => console.log(selected)}
 *      />
 *      <SelectBox
 *        id="disabled-option"
 *        label="ปิดใช้งาน"
 *        icon="/images/icon_qr.svg"
 *        iconHover="/images/qr_code_2_blue_24dp 1 (2).svg"
 *        selected={false}
 *        disabled={true}
 *      />
 *    </div>
 
 * การแสดงผล:
 * - ไอคอนแสดงด้านบน
 * - ข้อความแสดงด้านล่าง
 * - สีและสไตล์เปลี่ยนแปลงตามสถานะ
 * - รองรับ responsive design
 * - มี hover และ focus states
 * - รองรับ disabled state
 * 
 * สถานะต่างๆ:
 * - Default: สีเทา, ไอคอนปกติ
 * - Hover: สีน้ำเงิน, ไอคอน hover
 * - Selected: พื้นหลังน้ำเงินอ่อน, เส้นขอบน้ำเงิน, ไอคอน hover
 * - Disabled: สีเทา, opacity ลดลง, cursor not-allowed
 * 
 * Best Practices:
 * 1. ใช้ id ที่ไม่ซ้ำกันสำหรับแต่ละ select box
 * 2. จัดการ state ให้เหมาะสมกับ use case
 * 3. ใช้ไอคอนที่เหมาะสมกับฟังก์ชันการทำงาน
 * 4. ใช้ label ที่ชัดเจนและเข้าใจง่าย
 * 5. ตรวจสอบ accessibility (alt text สำหรับไอคอน)
 * 6. ใช้ controlled mode เมื่อต้องการควบคุม state จากภายนอก
 * 
 * การใช้งานกับ Form Libraries:
 * 
 * React Hook Form:
 * ```tsx
 * const { register, watch, setValue } = useForm();
 * const selectedValue = watch("paymentMethod");
 * 
 * <SelectBox
 *   id="qr"
 *   label="QR Code"
 *   icon="/images/icon_qr.svg"
 *   iconHover="/images/qr_code_2_blue_24dp 1 (2).svg"
 *   selected={selectedValue === "qr"}
 *   onClick={(selected) => setValue("paymentMethod", selected ? "qr" : "")}
 * />
 */ 
}),
"[project]/src/pages/index.tsx [ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/src/pages/index.tsx'\n\nExpected ',', got '}'");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b388d7d7._.js.map