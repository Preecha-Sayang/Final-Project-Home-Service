module.exports = [
"[project]/src/components/radio/radio_botton.tsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "default",
    ()=>__TURBOPACK__default__export__
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
;
function RadioButton({ id, name, value, checked = false, disabled = false, onChange, label }) {
    /**
   * ฟังก์ชันจัดการเมื่อมีการเปลี่ยนแปลงค่า
   * จะทำงานเฉพาะเมื่อปุ่มไม่ถูกปิดใช้งาน
   */ const handleChange = (e)=>{
        if (!disabled && onChange) {
            onChange(value);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "inline-block my-2",
        children: [
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                type: "radio",
                id: id,
                name: name,
                value: value,
                checked: checked,
                disabled: disabled,
                onChange: handleChange,
                className: "sr-only"
            }, void 0, false, {
                fileName: "[project]/src/components/radio/radio_botton.tsx",
                lineNumber: 35,
                columnNumber: 7
            }, this),
            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("label", {
                htmlFor: id,
                className: `
          flex items-center text-sm font-normal select-none transition-all duration-200
          ${disabled ? 'cursor-not-allowed text-gray-400' : 'cursor-pointer text-gray-700 hover:text-blue-500'}
        `,
                children: [
                    /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                        className: `
            relative w-[20px] h-[20px] mr-2 rounded-full border-2 bg-white transition-all duration-200
            ${disabled ? checked ? 'border-gray-300 bg-gray-50' : 'border-gray-300 bg-gray-50' : checked ? 'border-blue-500 bg-white' : 'border-gray-300 hover:border-blue-500'}
          `,
                        children: checked && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                            className: `
                absolute top-1/2 left-1/2 w-2 h-2 rounded-full transform -translate-x-1/2 -translate-y-1/2
                ${disabled ? 'bg-gray-400' : 'bg-blue-500'}
              `
                        }, void 0, false, {
                            fileName: "[project]/src/components/radio/radio_botton.tsx",
                            lineNumber: 73,
                            columnNumber: 13
                        }, this)
                    }, void 0, false, {
                        fileName: "[project]/src/components/radio/radio_botton.tsx",
                        lineNumber: 58,
                        columnNumber: 9
                    }, this),
                    label
                ]
            }, void 0, true, {
                fileName: "[project]/src/components/radio/radio_botton.tsx",
                lineNumber: 47,
                columnNumber: 7
            }, this)
        ]
    }, void 0, true, {
        fileName: "[project]/src/components/radio/radio_botton.tsx",
        lineNumber: 33,
        columnNumber: 5
    }, this);
}
const __TURBOPACK__default__export__ = RadioButton;
 /* ----------------------------------------------------
  วิธีใช้งาน RadioButton Component

  RadioButton Component เป็น custom radio button ที่มีสไตล์
  รองรับการใช้งานแบบ controlled และ uncontrolled
  มีการแสดงผลที่สอดคล้องกับ design system ของแอปพลิเคชัน
  ใช้สำหรับการเลือกตัวเลือกเดียวจากหลายตัวเลือก

  Props:
  - id: string (required) - ID ของ radio button (ต้องไม่ซ้ำกัน)
  - name: string (required) - ชื่อกลุ่มของ radio buttons (ต้องเหมือนกันในกลุ่ม)
  - value: string (required) - ค่าของ radio button
  - checked: boolean (optional) - สถานะการเลือก (default: false)
  - disabled: boolean (optional) - ปิดใช้งาน radio button (default: false)
  - onChange: function (optional) - ฟังก์ชันที่เรียกเมื่อมีการเปลี่ยนแปลงค่า
  - label: string (required) - ข้อความที่แสดงข้าง radio button

  ตัวอย่างการใช้งาน:

  1) การใช้งานพื้นฐาน:
     import RadioButton from "@/components/radio/radio_botton";
     
     const [selectedOption, setSelectedOption] = useState("");
     
     <div className="space-y-3">
       <RadioButton 
         id="option1"
         name="basic-options"
         value="option1"
         label="ตัวเลือกที่ 1"
         checked={selectedOption === "option1"}
         onChange={setSelectedOption}
       />
     </div>

  2) การใช้งานแบบ Disabled:
     <div className="space-y-2">
       <RadioButton 
         id="enabled-option"
         name="disabled-demo"
         value="enabled"
         label="ตัวเลือกที่ใช้งานได้"
         checked={true}
         onChange={(value) => console.log(value)}
       />
       <RadioButton 
         id="disabled-option"
         name="disabled-demo"
         value="disabled"
         label="ตัวเลือกที่ปิดใช้งาน"
         checked={false}
         disabled={true}
       />
     </div>


  การแสดงผล:
  - Radio button มีขนาด 20x20 pixels
  - สีน้ำเงินเมื่อถูกเลือก
  - สีเทาเมื่อปิดใช้งาน
  - มี hover effect เมื่อ hover
  - มี transition animation ที่นุ่มนวล
  - รองรับการแสดงผลแบบ responsive

  หมายเหตุ:
  - id ต้องไม่ซ้ำกันในหน้าเดียวกัน
  - name ต้องเหมือนกันในกลุ่ม radio buttons เดียวกัน
  - value ควรเป็นค่าที่ไม่ซ้ำกันในกลุ่ม
  - onChange จะไม่ทำงานเมื่อ disabled
  - รองรับการใช้งานแบบ controlled และ uncontrolled
  - ใช้กับ form libraries เช่น react-hook-form ได้

  การใช้งานกับ Form Libraries:
  
  React Hook Form:
     const { register, watch, setValue } = useForm();
     
     <RadioButton 
       id="form-radio"
       name="form-option"
       value="option1"
       label="ตัวเลือก 1"
       checked={watch('option') === 'option1'}
       onChange={(value) => setValue('option', value)}
     />

  Formik:
     <RadioButton 
       id="formik-radio"
       name="formik-option"
       value="option1"
       label="ตัวเลือก 1"
       checked={formik.values.option === 'option1'}
       onChange={(value) => formik.setFieldValue('option', value)}
     />

  การใช้งานแบบ Group Management:
     const [radioGroups, setRadioGroups] = useState({
       group1: "",
       group2: "",
       group3: ""
     });
     
     const handleGroupChange = (groupName: string, value: string) => {
       setRadioGroups(prev => ({
         ...prev,
         [groupName]: value
       }));
     };
     
     <div className="space-y-6">
       <div>
         <h3>กลุ่มที่ 1:</h3>
         <RadioButton 
           id="g1-option1"
           name="group1"
           value="option1"
           label="ตัวเลือก 1"
           checked={radioGroups.group1 === "option1"}
           onChange={(value) => handleGroupChange('group1', value)}
         />
       </div>
     </div>

---------------------------------------------------- */ }),
"[project]/src/components/radio/radio_input.tsx [ssr] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "RadioButtonWithInput",
    ()=>RadioButtonWithInput
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/react/jsx-dev-runtime [external] (react/jsx-dev-runtime, cjs)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$radio$2f$radio_botton$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/components/radio/radio_botton.tsx [ssr] (ecmascript)");
;
;
function RadioButtonWithInput({ id, name, value, checked, disabled, onChange, onInputChange, className, placeholder, inputValue, label, postfix = '฿' }) {
    /**
     * ฟังก์ชันจัดการเมื่อมีการเปลี่ยนแปลงค่าใน input field
     * จะทำงานเฉพาะเมื่อ input ไม่ถูกปิดใช้งาน
     */ const handleInputChange = (e)=>{
        if (!disabled && onInputChange) {
            onInputChange(e.target.value);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
        className: "space-y-3",
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
            className: "flex items-center space-x-4",
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$components$2f$radio$2f$radio_botton$2e$tsx__$5b$ssr$5d$__$28$ecmascript$29$__["default"], {
                    id: id,
                    name: name,
                    value: value,
                    label: label,
                    checked: checked,
                    disabled: disabled,
                    onChange: onChange
                }, void 0, false, {
                    fileName: "[project]/src/components/radio/radio_input.tsx",
                    lineNumber: 105,
                    columnNumber: 17
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                    className: "flex-1 max-w-xs",
                    children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                        className: `relative ${className}`,
                        children: [
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("input", {
                                type: "text",
                                value: inputValue || "",
                                onChange: handleInputChange,
                                placeholder: placeholder,
                                disabled: disabled,
                                className: `
                                w-full h-[42px] pt-[9px] pr-[13px] pb-[9px] pl-[13px]
                                bg-gray-100 
                                border border-gray-300 
                                rounded-[6px] 
                                text-sm 
                                text-gray-700
                                placeholder-gray-400
                                focus:outline-none 
                                focus:ring-2 
                                focus:ring-blue-500 
                                focus:border-transparent
                                transition-all duration-200
                                shadow-sm
                                ${disabled ? 'cursor-not-allowed bg-gray-50 text-gray-400' : 'hover:bg-gray-50'}
                            `
                            }, void 0, false, {
                                fileName: "[project]/src/components/radio/radio_input.tsx",
                                lineNumber: 118,
                                columnNumber: 25
                            }, this),
                            /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("div", {
                                className: "absolute right-[13px] top-1/2 transform -translate-y-1/2 pointer-events-none",
                                children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$externals$5d2f$react$2f$jsx$2d$dev$2d$runtime__$5b$external$5d$__$28$react$2f$jsx$2d$dev$2d$runtime$2c$__cjs$29$__["jsxDEV"])("span", {
                                    className: "text-gray-500 text-sm font-medium",
                                    children: postfix
                                }, void 0, false, {
                                    fileName: "[project]/src/components/radio/radio_input.tsx",
                                    lineNumber: 147,
                                    columnNumber: 29
                                }, this)
                            }, void 0, false, {
                                fileName: "[project]/src/components/radio/radio_input.tsx",
                                lineNumber: 146,
                                columnNumber: 25
                            }, this)
                        ]
                    }, void 0, true, {
                        fileName: "[project]/src/components/radio/radio_input.tsx",
                        lineNumber: 117,
                        columnNumber: 21
                    }, this)
                }, void 0, false, {
                    fileName: "[project]/src/components/radio/radio_input.tsx",
                    lineNumber: 116,
                    columnNumber: 17
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/components/radio/radio_input.tsx",
            lineNumber: 104,
            columnNumber: 13
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/components/radio/radio_input.tsx",
        lineNumber: 102,
        columnNumber: 9
    }, this);
} /**
 * วิธีใช้งาน RadioButtonWithInput Component
 * 
 * RadioButtonWithInput Component เป็นคอมโพเนนต์ที่รวม radio button กับ input field
 * เหมาะสำหรับการเลือกตัวเลือกพร้อมกับการป้อนข้อมูลเพิ่มเติม
 * 
 * คุณสมบัติหลัก:
 * - Radio button สำหรับเลือกตัวเลือก
 * - Input field สำหรับป้อนข้อมูลเพิ่มเติม
 * - รองรับการปิดใช้งาน (disabled state)
 * - มี postfix แสดงด้านขวาของ input (เช่น สัญลักษณ์สกุลเงิน)
 * - สไตล์ที่สอดคล้องกับ design system
 * 
 * ตัวอย่างการใช้งาน:
 * 
 * 1) การใช้งานพื้นฐาน - การเลือกวิธีการชำระเงิน:
 *    const [selectedPayment, setSelectedPayment] = useState("");
 *    const [amount, setAmount] = useState("");
 *    
 *    <div className="space-y-4">
 *      <RadioButtonWithInput
 *        id="cash-payment"
 *        name="payment-method"
 *        value="cash"
 *        label="เงินสด"
 *        checked={selectedPayment === "cash"}
 *        onChange={setSelectedPayment}
 *        inputValue={amount}
 *        onInputChange={setAmount}
 *        placeholder="ระบุจำนวนเงิน"
 *        postfix="฿"
 *      />
 *    </div>
 * 
 * 3) การใช้งานแบบ Disabled:
 *    <div className="space-y-3">
 *      <RadioButtonWithInput
 *        id="enabled-option"
 *        name="demo"
 *        value="enabled"
 *        label="ตัวเลือกที่ใช้งานได้"
 *        checked={true}
 *        onChange={(value) => console.log(value)}
 *        inputValue="1000"
 *        onInputChange={(value) => console.log(value)}
 *        placeholder="ระบุจำนวน"
 *        postfix="฿"
 *      />
 *      <RadioButtonWithInput
 *        id="disabled-option"
 *        name="demo"
 *        value="disabled"
 *        label="ตัวเลือกที่ปิดใช้งาน"
 *        checked={false}
 *        disabled={true}
 *        inputValue=""
 *        placeholder="ไม่สามารถป้อนข้อมูลได้"
 *        postfix="฿"
 *      />
 *    </div>
 * 
 * การแสดงผล:
 * - Radio button แสดงด้านซ้าย
 * - Input field แสดงด้านขวาของ radio button
 * - Postfix แสดงด้านขวาของ input field
 * - รองรับ responsive design
 * - มี hover และ focus states
 * - รองรับ disabled state
 * 
 * Best Practices:
 * 1. ใช้ name เดียวกันสำหรับ radio button ที่อยู่ในกลุ่มเดียวกัน
 * 2. ใช้ id ที่ไม่ซ้ำกันสำหรับแต่ละ radio button
 * 3. จัดการ state ให้เหมาะสมกับ use case
 * 4. ใช้ placeholder ที่ชัดเจนและเข้าใจง่าย
 * 5. เลือก postfix ที่เหมาะสมกับข้อมูลที่ป้อน
 * 6. ตรวจสอบ validation ของข้อมูลที่ป้อนใน input field
 * 
 * การใช้งานกับ Form Libraries:
 * 
 * React Hook Form:
 * ```tsx
 * const { register, watch, setValue } = useForm();
 * const selectedValue = watch("paymentMethod");
 * const inputValue = watch("amount");
 * 
 * <RadioButtonWithInput
 *   id="cash"
 *   name="paymentMethod"
 *   value="cash"
 *   label="เงินสด"
 *   checked={selectedValue === "cash"}
 *   onChange={(value) => setValue("paymentMethod", value)}
 *   inputValue={inputValue}
 *   onInputChange={(value) => setValue("amount", value)}
 *   placeholder="ระบุจำนวนเงิน"
 *   postfix="฿"
 * />
 */ 
}),
"[project]/src/pages/index.tsx [ssr] (ecmascript)", ((__turbopack_context__, module, exports) => {

const e = new Error("Could not parse module '[project]/src/pages/index.tsx'\n\nParenthesized expression cannot be empty");
e.code = 'MODULE_UNPARSABLE';
throw e;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__b86408c6._.js.map