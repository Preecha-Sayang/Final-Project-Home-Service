globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_46a35751._.js",
      "static/chunks/node_modules_next_dist_client_379e9c20._.js",
      "static/chunks/node_modules_next_dist_2ff056ee._.js",
      "static/chunks/node_modules_next_0a36fc09._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_64fd8a85._.js",
      "static/chunks/[root-of-the-server]__206ad862._.js",
      "static/chunks/src_pages_index_2da965e7._.js",
      "static/chunks/turbopack-src_pages_index_9d776a1c._.js"
    ],
    "/404": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
      "static/chunks/node_modules_next_dist_shared_lib_f041b118._.js",
      "static/chunks/node_modules_next_dist_client_3ede7da4._.js",
      "static/chunks/node_modules_next_dist_2e2215b7._.js",
      "static/chunks/node_modules_next_link_207af988.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_db346ff0._.js",
      "static/chunks/[root-of-the-server]__3bab634e._.js",
      "static/chunks/[next]_internal_font_google_prompt_6c2a56eb_module_97d8c2bb.css",
      "static/chunks/src_pages_404_2da965e7._.js",
      "static/chunks/turbopack-src_pages_404_031716ad._.js"
    ],
    "/_app": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_e5a37f7a._.js",
      "static/chunks/node_modules_next_dist_shared_lib_854924ee._.js",
      "static/chunks/node_modules_next_dist_client_45e9549c._.js",
      "static/chunks/node_modules_next_dist_2e2215b7._.js",
      "static/chunks/node_modules_next_f1a19c82._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
      "static/chunks/node_modules_ccf09c08._.js",
      "static/chunks/[root-of-the-server]__e1e2876f._.js",
      "static/chunks/[root-of-the-server]__ca428f58._.css",
      "static/chunks/src_pages__app_2da965e7._.js",
      "static/chunks/turbopack-src_pages__app_293fc44a._.js"
    ],
    "/_error": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_166120c5._.js",
      "static/chunks/node_modules_next_dist_shared_lib_b4122b32._.js",
      "static/chunks/node_modules_next_dist_client_d0aa886c._.js",
      "static/chunks/node_modules_next_dist_0cccb603._.js",
      "static/chunks/node_modules_next_error_1cfbb379.js",
      "static/chunks/[next]_entry_page-loader_ts_43b523b5._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_db4bb196._.js",
      "static/chunks/[root-of-the-server]__a2d5dfc8._.js",
      "static/chunks/src_pages__error_2da965e7._.js",
      "static/chunks/turbopack-src_pages__error_cec5bb8d._.js"
    ],
    "/login": [
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_6cf7e6c4._.js",
      "static/chunks/node_modules_next_dist_client_e4371d1d._.js",
      "static/chunks/node_modules_next_dist_2ff056ee._.js",
      "static/chunks/node_modules_next_f6e12e7e._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_be8bb86a._.js",
      "static/chunks/[root-of-the-server]__b1124235._.js",
      "static/chunks/src_pages_login_index_tsx_2da965e7._.js",
      "static/chunks/turbopack-src_pages_login_index_tsx_4175cd67._.js"
    ],
    "/register": [
      "static/chunks/[root-of-the-server]__c232e188._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_aa9d047d._.js",
      "static/chunks/node_modules_next_dist_shared_lib_6cf7e6c4._.js",
      "static/chunks/node_modules_next_dist_client_e4371d1d._.js",
      "static/chunks/node_modules_next_dist_2ff056ee._.js",
      "static/chunks/node_modules_next_f6e12e7e._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_919e40ef._.js",
      "static/chunks/src_pages_register_index_tsx_2da965e7._.js",
      "static/chunks/turbopack-src_pages_register_index_tsx_fcb832d7._.js"
    ],
    "/userprofile": [
      "static/chunks/[root-of-the-server]__ae2e6f14._.js",
      "static/chunks/node_modules_next_dist_compiled_next-devtools_index_5277ebc8.js",
      "static/chunks/node_modules_next_dist_compiled_98c9bed4._.js",
      "static/chunks/node_modules_next_dist_shared_lib_46a35751._.js",
      "static/chunks/node_modules_next_dist_client_379e9c20._.js",
      "static/chunks/node_modules_next_dist_2ff056ee._.js",
      "static/chunks/node_modules_next_f1d42476._.js",
      "static/chunks/node_modules_react-dom_4411d9bd._.js",
      "static/chunks/node_modules_axios_lib_2c8bf6cb._.js",
      "static/chunks/node_modules_@headlessui_react_dist_c866b64e._.js",
      "static/chunks/node_modules_@floating-ui_react_dist_ca3caa08._.js",
      "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_0ab97e45._.js",
      "static/chunks/node_modules_a835eddb._.js",
      "static/chunks/src_pages_userprofile_2da965e7._.js",
      "static/chunks/turbopack-src_pages_userprofile_a8d07e44._.js"
    ]
  },
  "devFiles": [],
  "ampDevFiles": [],
  "polyfillFiles": [],
  "lowPriorityFiles": [],
  "rootMainFiles": [],
  "ampFirstPages": []
};
globalThis.__BUILD_MANIFEST.lowPriorityFiles = [
"/static/" + process.env.__NEXT_BUILD_ID + "/_buildManifest.js",
,"/static/" + process.env.__NEXT_BUILD_ID + "/_ssgManifest.js",

];