var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/categories.js")
R.c("server/chunks/node_modules_86c1c9cc._.js")
R.c("server/chunks/[root-of-the-server]__27166372._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/categories/index.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/categories/index.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
