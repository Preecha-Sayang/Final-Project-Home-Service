var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/services-cards.js")
R.c("server/chunks/node_modules_5ee36488._.js")
R.c("server/chunks/[root-of-the-server]__82852e5f._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/services-cards.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/services-cards.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
