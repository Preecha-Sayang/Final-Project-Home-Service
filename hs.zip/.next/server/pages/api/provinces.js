var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/provinces.js")
R.c("server/chunks/node_modules_71576e67._.js")
R.c("server/chunks/[root-of-the-server]__f85ef1d4._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/provinces.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/provinces.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
