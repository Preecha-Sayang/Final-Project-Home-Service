var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/location/provinces.js")
R.c("server/chunks/node_modules_74a35362._.js")
R.c("server/chunks/[root-of-the-server]__2d865f42._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/location/provinces.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/location/provinces.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
