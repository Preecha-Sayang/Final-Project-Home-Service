var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/location/districts.js")
R.c("server/chunks/node_modules_41a509e3._.js")
R.c("server/chunks/[root-of-the-server]__ef2f57fd._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/location/districts.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/location/districts.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
