var R=require("../../../chunks/[turbopack]_runtime.js")("server/pages/api/auth/login.js")
R.c("server/chunks/node_modules_781b0fa7._.js")
R.c("server/chunks/[root-of-the-server]__3686c4cc._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/auth/login.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/auth/login.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
