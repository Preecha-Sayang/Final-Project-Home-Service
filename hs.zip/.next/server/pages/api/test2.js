var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/test2.js")
R.c("server/chunks/node_modules_bdfe7841._.js")
R.c("server/chunks/[root-of-the-server]__0a289434._.js")
R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/test2.ts [api] (ecmascript)\" } [api] (ecmascript)")
module.exports=R.m("[project]/node_modules/next/dist/esm/build/templates/pages-api.js { INNER_PAGE => \"[project]/src/pages/api/test2.ts [api] (ecmascript)\" } [api] (ecmascript)").exports
