var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/node_modules_cd1b5fda._.js")
R.c("server/chunks/ssr/[root-of-the-server]__4793a0a5._.js")
R.m("[project]/src/pages/_document.tsx [ssr] (ecmascript)")
module.exports=R.m("[project]/src/pages/_document.tsx [ssr] (ecmascript)").exports
